#soal no 3
print("3. Suraji mempunyai uang kertas bernilai US$35, ia ingin menukarkannya ke mata uang dari negara asalnya yaitu negara Indonesia. Bantulah Suraji untuk menghitung nominal uang yang didapatkannya dengan mata uang negara asalnya tersebut (Gunakan kurs sesuai dengan tanggal praktikum) !")
print("jawaban : ")
#menghitung nominal uang dengan kurs
print("menghitung nominal uang dengan kurs")
kurs_usd = int(input("mata uang dollar: "))
kurs_usd_to_indr = int(input("mata uang rupiah: "))
jumlah_idr = kurs_usd_to_indr * kurs_usd
print("jadi nominal uang yang di tukar adalah rp", jumlah_idr)