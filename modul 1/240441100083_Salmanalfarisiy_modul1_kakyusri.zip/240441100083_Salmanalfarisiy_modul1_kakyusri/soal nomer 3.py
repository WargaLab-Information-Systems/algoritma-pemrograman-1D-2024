#soal nomer 3
dolar = 35
rupiah = 15.26193
tukar =float( dolar * rupiah)

print(float(tukar))