#soal nomer 4

n = 7
r = 4
import math
jumlah_cara = math.factorial(n)/(math.factorial(r)*math.factorial(n-r))
print(f"jumlah cara untuk membuat tim: {jumlah_cara}")
print(math.factorial(n))