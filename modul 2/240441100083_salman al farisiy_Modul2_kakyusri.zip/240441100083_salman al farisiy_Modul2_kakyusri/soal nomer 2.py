#soal nomer 2
# skor_jaka = 1000
# ipk_jaka = 3.5

# skor_ida = 11000
# ipk_ida = 3.5

# ipk=3.5
# skor=1100


# if skor_jaka >= skor and ipk_jaka >=ipk:
#     print("jaka lulus")
# else:
#     print("jaka tidak lulus")

# if skor_ida >= skor and ipk_ida >=ipk:
#     print("ida lulus")
# else:
#     print("ida tidak lulus")
