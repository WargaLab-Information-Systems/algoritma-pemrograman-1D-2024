#soal nomer 5
# nama = input("nama pembeli:")
# usia = int (input("masukkan usia anda:"))
# if  usia < 18:
#     print("maaf usia belum mencukupi")
#     exit()

# total_belanja = float(input("masukkan total belanja anda:"))
# member = input("apakah anda memiliki member? iya/tidak:")
# if member == "iya":
#     member = True
# else:
#     member = False
# if total_belanja >= 500000:
#     diskon = 0.10
# else :
#     diskon = 0
# if member:
#         diskon += 0.15

        
# diskon_rupiah = total_belanja * diskon
# total_bayar = total_belanja - diskon_rupiah

# print("nama anda:", nama)
# print("diskon yang anda dapatkan:",diskon* 100, "%" )
# print("total harga sebelum diskon", total_belanja )
# print("total harga anda:", total_bayar)