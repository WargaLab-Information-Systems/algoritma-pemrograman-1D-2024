makan = input("apakah kamu sudah makan? : ")
mandi = input("apakah anda sudah mandi : ")
transportasi = input("pilih transportasi :")

if makan < y :
    print("kamu diberi waktu 15 menit untuk makan")
    exit()
    
print=(int("apakah anda sudah mandi?"))
print=(int("iya"))
print=(int("apakah anda sudah makan?"))
print=(int("tidak"))

while True:
    if int(input("30 menit")):
        print(input("kamu berangkat tepat waktu"))
    elif int(input("50 menit")):
        print(input("kamu berangkat tepat waktu"))
    elif int(input("65 menit")):
        print(input("kamu terlambat"))
    else:
        "kamu tidak hadir"