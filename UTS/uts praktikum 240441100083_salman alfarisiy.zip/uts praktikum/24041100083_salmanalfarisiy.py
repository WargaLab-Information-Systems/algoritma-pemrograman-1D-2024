makan = 15 
mandi = 10
transport = ("sepeda")

tanya = input("apakah kamu sudah mandi iya/tidak")
tanya2 = input("apakah kamu sudah mandi iya/tidak")
tanya3= input("pilih kendaraan")
if True:
    tanya =("iya")
    False
while True:
    if tanya =="iya"and tanya2 =="iya":
        print("kamu boelh berangkat")
    elif tanya2:
        print("kamu harus memilih kendaraan")
    else:
        print("kamu harus makan", makan,"menit") 
        break




