dolar = 35
rupiah = dolar * 15200
print("konversi dolar ke rupiah:", rupiah)